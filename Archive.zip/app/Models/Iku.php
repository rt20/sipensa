<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Iku extends Model
{
      //biar bisa diinput ke database lebih simpel dibanding fillable
      protected $guarded = [];
}
