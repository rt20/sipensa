<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Budget extends Model
{
    //biar bisa diinput ke database lebih simpel dibanding fillable
    protected $guarded = [];

    
}
