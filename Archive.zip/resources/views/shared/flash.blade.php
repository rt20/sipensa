@if(flash()->message)
<div>
     {{ flash()->message }}
</div>
@endif