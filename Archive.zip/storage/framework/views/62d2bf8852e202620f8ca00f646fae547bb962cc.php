<?php $__env->startSection('content'); ?>
<!-- Content Header (Page header) -->
<section class="content-header">
    <div class="container-fluid">
        <div class="row mb-0">
            <div class="col-sm-9">
                <h1>Data Pegawai</h1>
            </div>
            <div class="col-sm-3">
                <ol class="breadcrumb float-sm-right">
                    <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>">Dashboard</a></li>
                    <li class="breadcrumb-item"><a href="<?php echo e(route('user.index')); ?>">Pegawai</a></li>
                    <li class="breadcrumb-item active">Ubah</li>
                </ol>
            </div>
        </div>
    </div><!-- /.container-fluid -->
</section>
<section class="content">
    <div class="card">
        <div class="card-header">
            <form action="<?php echo e(route('user.update', $user->id)); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <?php echo e(method_field("PATCH")); ?>


                <div class="col-md-6">
                    <label>Nama</label>
                    <input type="text" name="name" class="form-control" value="<?php echo e($user->name); ?>" required>
                </div>
                <div class="col-md-6">
                    <label>NIP/NIK</label>
                    <input type="number" name="nip" class="form-control" value="<?php echo e($user->nip); ?>" required>
                </div>
                <div class="col-md-6">
                    <label>Jabatan</label>
                    <input type="text" name="jabatan" class="form-control" value="<?php echo e($user->jabatan); ?>" required>
                </div>
                <div class="col-md-6">
                    <label>Subdit</label>
                    <select name="subdit_id" class="form-control">
                        <option value="">Pilih Subdit</option>
                        <?php $__currentLoopData = $subdit; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subdit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($subdit->id); ?>" <?php echo e($user->subdit_id == $subdit->id ? 'selected' : null); ?>>
                            <?php echo e($subdit->subdit); ?> </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="col-md-6">
                    <label>Email</label>
                    <input type="text" name="email" class="form-control" value="<?php echo e($user->email); ?>" required>
                </div>
                <div class="col-md-6 mt-3">
                    <button type="submit" class="btn btn-primary">Simpan</button>
                </div>
            </form>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('lte.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/webhozz3/resources/views/user/edit.blade.php ENDPATH**/ ?>