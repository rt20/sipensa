<?php $__env->startSection('content'); ?>
<!-- Content Header (Page header) -->
<section class="content-header">
    <div class="container-fluid">
        <div class="row mb-0">
            <div class="col-sm-9">
                <h1>Audit Sarana oleh <?php echo e(Auth::user()->name); ?></h1>
            </div>
            <div class="col-sm-3">
                <ol class="breadcrumb float-sm-right">
                    <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>">Dashboard</a></li>
                    <li class="breadcrumb-item active">Audit</li>
                </ol>
            </div>  
        </div>
    </div><!-- /.container-fluid -->
</section>
<section class="content">
<div class="card">
    <div class="card-header">
        <a href="<?php echo e(route('audit.create')); ?>" class="btn btn-primary" title="Tambah Audit"><i class="nav-icon fas fa-plus-circle"></i> </a>
        <a href="<?php echo e(route('export')); ?>" class="btn btn-success">Unduh</a>
        </div>
        <div class="card-body">
        <table class="table">
            <thead class="thead-light">
                <tr>
                    <th scope="col">No</th>
                    <th scope="col">Nama Sarana</th>
                    <th scope="col">Tgl Audit</th>
                    <th scope="col">Lokasi</th>
                    <th scope="col">Status</th>
                    <th scope="col" colspan="2">Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <th><?php echo e(($data->currentPage()-1) * $data->perPage()+$loop->index+1); ?></th>
                    <td><?php echo e($row->nama); ?></td>
                    <td><?php echo e(date('d-M-y', strtotime($row->tgl_audit))); ?></td>
                    <td><?php echo e($row->lokasi); ?></td>
                    <td>
                        <?php if($row->status_capa == 'Ditugaskan melakukan audit'): ?>
                        <span class="badge badge-dark">
                            <?php elseif($row->status_capa == 'Telah melaksanakan audit'): ?>
                            <span class="badge badge-primary">
                                <?php elseif($row->status_capa == 'Mengirimkan hasil audit ke sarana'): ?>
                                <span class="badge badge-danger">
                                    <?php elseif($row->status_capa == 'Menerima laporan TL CAPA'): ?>
                                    <span class="badge badge-warning">
                                        <?php elseif($row->status_capa == 'Melakukan evaluasi CAPA'): ?>
                                        <span class="badge badge-info">
                                            <?php elseif($row->status_capa == 'Menyelesaikan audit sarana'): ?>
                                            <span class="badge badge-success">
                                                <?php else: ?>
                                                <span>
                                                    <?php endif; ?>
                                                    <?php echo e($row->status_capa); ?>

                                                </span>
                    </td>
                    <td align=right>
                        <?php if($row->status_capa == 'Ditugaskan melakukan audit'): ?>
                        <a href="<?php echo e(route('audit.edit', $row->id)); ?>" class="btn btn-success btn-sm" title="Ubah">
                            <i class="fa fa-edit"></i></a>
                        <?php endif; ?>
                        <a href="<?php echo e(route('audit.show', $row->id)); ?>" class="btn btn-info btn-sm" title="Detail">
                            <i class="fa fa-eye"></i></a>
                        <form action="<?php echo e(route('audit.destroy', $row->id)); ?>" method="post" class="d-inline" title="Hapus">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('delete'); ?>
                            <button class="btn btn-danger btn-sm " onclick="return confirm('Apakah anda yakin ?')">
                                <i class="fa fa-trash"></i>
                            </button>
                        </form>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="8">Data tidak ditemukan</td>
                </tr>
                <?php endif; ?>

            </tbody>
        </table>

    </div>

</div>

<?php echo $data->render(); ?>

</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('lte.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/webhozz3/resources/views/audit/index.blade.php ENDPATH**/ ?>