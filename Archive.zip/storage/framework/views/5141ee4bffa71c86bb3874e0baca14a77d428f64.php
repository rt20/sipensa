<?php $__env->startSection('content'); ?>
<!-- Content Header (Page header) -->
<section class="content-header">
    <div class="container-fluid">
        <div class="row mb-0">
            <div class="col-sm-6">
                <h1>Anggaran</h1>
            </div>
            <div class="col-sm-6">
                <ol class="breadcrumb float-sm-right">
                    <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>">Dashboard</a></li>
                    <li class="breadcrumb-item"><a href="<?php echo e(route('budget.index')); ?>">Anggaran</a></li>
                </ol>
            </div>
        </div>
    </div><!-- /.container-fluid -->
</section>
<section class="content">
    <div class="card">
        <div class="card-header">
            <a href="<?php echo e(route('budget.create')); ?>" class="btn btn-primary mb-3">Tambah Anggaran</a>

            <table class="table">
                <thead class="thead-light">
                    <tr>
                        <th scope="col">No</th>
                        <th scope="col">Kode</th>
                        <th scope="col">Uraian</th>
                        <th scope="col">Pagu</th>
                        <th scope="col">Realisasi</th>
                        <th scope="col">Sisa</th>
                        <th scope="col">Keterangan</th>
                        <th scope="col" colspan="2">Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <th><?php echo e($loop->index +1); ?></th>
 
                        <td><?php echo e($row->kode); ?></td>
                        <td><?php echo e($row->uraian); ?></td>
                        <td><?php echo e(number_format($row->pagu)); ?></td>
                        <td><?php echo e(number_format($row->realisasi)); ?></td>
                        <td><?php echo e(number_format($row->sisa)); ?></td>
                        <td><?php echo e($row->keterangan); ?></td>

                        <td>
                            <a href="<?php echo e(route('budget.edit', $row->id)); ?>" class="btn btn-success btn-sm"><i
                                    class="fa fa-edit"></i></a>
                            <form action="<?php echo e(route('budget.destroy', $row->id)); ?>" method="post" class="d-inline">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('delete'); ?>
                                <button class="btn btn-danger btn-sm" onclick="return confirm('Apakah anda yakin ?')">
                                    <i class="fa fa-trash"></i>
                                </button>
                            </form>
                        </td>
                    </tr>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="8">Data tidak ditemukan</td>
                    </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
    <?php echo $data->render(); ?>

</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('lte.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/webhozz3/resources/views/budget/index.blade.php ENDPATH**/ ?>