<?php $__env->startSection('content'); ?>
<?php echo $__env->make('shared.errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- Content Header (Page header) -->
<section class="content-header">
    <div class="container-fluid">
        <div class="row mb-0">
            <div class="col-sm-6">
                <h1>Tambah Data Anggaran</h1>
                * harus diisi
            </div>
            <div class="col-sm-6">
                <ol class="breadcrumb float-sm-right">
                    <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>">Dashboard</a></li>
                    <li class="breadcrumb-item"><a href="<?php echo e(route('budget.index')); ?>">Anggaran</a></li>
                    <li class="breadcrumb-item active">Tambah</li>
                </ol>
            </div>
        </div>
    </div><!-- /.container-fluid -->
</section>
<section class="content">
    <div class="card">
        <div class="card-header">
            <form action="<?php echo e(asset("/budget")); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <div class="col-md-6">
                    <label>Kode Anggaran</label>
                    <input type="text" name="kode" placeholder="eg: 121837182" class="form-control"
                        value="<?php echo e(old('kode')); ?>">
                </div>
                <div class="col-md-6">
                    <label>Nama Kegiatan</label>
                    <input type="text" name="uraian" class="form-control" value="<?php echo e(old('uraian')); ?>">
                </div>
                <div class="col-md-6">
                    <label>Pagu</label>
                    <input type="number" name="pagu" class="form-control" value="<?php echo e(old('pagu')); ?>">
                </div>
                <div class="col-md-6">
                    <label>Realisasi</label>
                    <input type="number" name="realisasi" class="form-control" value="<?php echo e(old('realisasi')); ?>" disabled>
                </div>
                <div class="col-md-6">
                    <label>Sisa</label>
                    <input type="number" name="sisa" class="form-control" value="<?php echo e(old('sisa')); ?>" disabled>
                </div>
                <div class="col-md-6">
                    <label>Keterangan</label>
                    <textarea name="keterangan" class="form-control"> <?php echo e(old('keterangan')); ?></textarea>
                </div>
                <div class="col-md-6 mt-3">
                    <button type="submit" class="btn btn-primary">Save</button>
                </div>
            </form>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('lte.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/webhozz3/resources/views/budget/create.blade.php ENDPATH**/ ?>