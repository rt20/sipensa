<?php $__env->startSection('content'); ?>

<!-- Content Header (Page header) -->
<section class="content-header">
    <div class="container-fluid">
        <div class="row mb-0">
            <div class="col-sm-6">
                <h1>Indikator Kinerja Unit Kerja</h1>
            </div>
            <div class="col-sm-6">
                <ol class="breadcrumb float-sm-right">
                    <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>">Dashboard</a></li>
                    <li class="breadcrumb-item active">Kinerja</li>
                </ol>
            </div>
        </div>
    </div><!-- /.container-fluid -->
</section>
<section class="content">
<!-- Default box -->
<div class="card">
    <div class="card-header">
        <?php if(Auth::user()->roles == '["ADMIN"]'): ?>
        <a href="<?php echo e(route('iku.create')); ?>" class="btn btn-primary mb-3">Tambah Indikator Kinerja</a>
        <?php endif; ?>
        <table class="table">
            <thead class="thead-light">
                <tr>
                    <th scope="col">No</th>
                    <!-- <th scope="col">Kode</th> -->
                    <th scope="col">Sasaran Strategis</th>
                    <th scope="col">Indikator Kinerja</th>
                    <th scope="col">Target</th>
                    <th scope="col">Realisasi</th>
                    <?php if(Auth::user()->roles == '["ADMIN"]'): ?>
                    <th scope="col" colspan="2">Action</th>
                    <?php endif; ?>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <th><?php echo e(($data->currentPage()-1) * $data->perPage()+$loop->index+1); ?></th>
                    <td><?php echo e($row->sasaran); ?></td>
                    <td><?php echo e($row->indikator); ?></td>
                    <td><?php echo e($row->target); ?></td>
                    <td><?php echo e($row->realisasi); ?></td>
                    <?php if(Auth::user()->roles == '["ADMIN"]'): ?>
                    <td>

                        <a href="<?php echo e(route('iku.edit', $row->id)); ?>" class="btn btn-success">Ubah</a>

                    </td>
                    <td>
                        <form action="<?php echo e(route('iku.destroy', $row->id)); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <?php echo e(method_field('DELETE')); ?>

                            <button type="submit" class="btn btn-danger">Hapus</button>
                        </form>
                    </td>
                    <?php endif; ?>
                </tr>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>

    <!-- /.card-body -->

    <!-- /.card-footer-->
</div>
<?php echo $data->render(); ?>

    
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('lte.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/webhozz3/resources/views/iku/index.blade.php ENDPATH**/ ?>