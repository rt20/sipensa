<!DOCTYPE html>
<html lang="en">
<head>
	<title>SIPENSA</title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
<!--===============================================================================================-->	
<link rel="icon" type="image/png" href="<?php echo e(asset("/loginv4/images/icons/favicon.ico")); ?>"/>
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset("/loginv4/vendor/bootstrap/css/bootstrap.min.css")); ?>">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset("/loginv4/fonts/font-awesome-4.7.0/css/font-awesome.min.css")); ?>">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset("/loginv4/fonts/iconic/css/material-design-iconic-font.min.css")); ?>">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset("/loginv4/vendor/animate/animate.css")); ?>">
<!--===============================================================================================-->	
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset("/loginv4/vendor/css-hamburgers/hamburgers.min.css")); ?>">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset("/loginv4/vendor/animsition/css/animsition.min.css")); ?>">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset("/loginv4/vendor/select2/select2.min.css")); ?>">
<!--===============================================================================================-->	
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset("/loginv4/vendor/daterangepicker/daterangepicker.css")); ?>">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset("/loginv4/css/util.css")); ?>">
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset("/loginv4/css/main.css")); ?>">
<body>
	
	<div class="limiter">
		<div class="container-login100" style="background-image: url('/loginv4/images/bg-01.jpg');">
			<div class="wrap-login100 p-l-55 p-r-55 p-t-65 p-b-54">
				<form method="POST" action="<?php echo e(route('login')); ?>">
					<span class="login100-form-title p-b-10">
                    <a href="#"><img height="100px" width="100px" src="<?php echo e(asset("/adminlte/img/logo_big.png")); ?>"></a>
						<br>SIPENSA</br>
					</span>

					<div class="wrap-input100 validate-input m-b-23" data-validate = "Username is required">
						
						<!-- <input class="input100" type="text" name="login" placeholder="NIP"> -->
                        <input type="text" class="input100 <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                    name="login" placeholder="NIP" value="<?php echo e(old('login')); ?>" required autocomplete="email" autofocus>
                                    <?php $__errorArgs = ['login'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
						<span class="focus-input100" data-symbol="&#xf206;"></span>
					</div>

					<div class="wrap-input100 validate-input" data-validate="Password is required">
						
						<!-- <input class="input100" type="password" name="pass" placeholder="Type your password"> -->
                        <input id="password" type="password" class="input100 <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Kata Sandi" name="password" required autocomplete="current-password">



						<span class="focus-input100" data-symbol="&#xf190;"></span>
					</div>
					
					<div class="text-right p-t-8 p-b-31">
						<a href="#">
							Lupa Kata Sandi?
						</a>
					</div>
					
					<div class="container-login100-form-btn">
						<div class="wrap-login100-form-btn">
							<div class="login100-form-bgbtn"></div>
							<button class="login100-form-btn">
								Masuk
							</button>
						</div>
					</div>

					

					

				
				</form>
			</div>
		</div>
	</div>
	

	<div id="dropDownSelect1"></div>
	
    <script src="<?php echo e(asset("/loginv4/vendor/jquery/jquery-3.2.1.min.js")); ?>"></script>
<!--===============================================================================================-->
	<script src="<?php echo e(asset("/loginv4/vendor/animsition/js/animsition.min.js")); ?>"></script>
<!--===============================================================================================-->
	<script src="<?php echo e(asset("/loginv4/vendor/bootstrap/js/popper.js")); ?>"></script>
	<script src="<?php echo e(asset("/loginv4/vendor/bootstrap/js/bootstrap.min.js")); ?>"></script>
<!--===============================================================================================-->
	<script src="<?php echo e(asset("/loginv4/vendor/select2/select2.min.js")); ?>"></script>
<!--===============================================================================================-->
	<script src="<?php echo e(asset("/loginv4/vendor/daterangepicker/moment.min.js")); ?>"></script>
	<script src="<?php echo e(asset("/loginv4/vendor/daterangepicker/daterangepicker.js")); ?>"></script>
<!--===============================================================================================-->
	<script src="<?php echo e(asset("/loginv4/vendor/countdowntime/countdowntime.js")); ?>"></script>
<!--===============================================================================================-->
	<script src="<?php echo e(asset("/loginv4/js/main.js")); ?>"></script>
</body>
</html><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/webhozz3/resources/views/auth/ijinrt.blade.php ENDPATH**/ ?>