<?php $__env->startSection('content'); ?>
<?php echo $__env->make('shared.errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- Content Header (Page header) -->
<section class="content-header">
    <div class="container-fluid">
        <div class="row mb-0">
            <div class="col-sm-6">
                <h1>Tambah Surat Tugas</h1>
            </div>
            <div class="col-sm-6">
                <ol class="breadcrumb float-sm-right">
                    <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>">Dashboard</a></li>
                    <li class="breadcrumb-item"><a href="<?php echo e(route('stugas.index')); ?>">Surat Tugas</a></li>
                    <li class="breadcrumb-item active">Tambah</li>
                </ol>
            </div>
        </div>
    </div><!-- /.container-fluid -->
</section>
<section class="content"> 
    <div class="card">
        <div class="card-header">
            <!-- <form action="<?php echo e(asset("/stugas")); ?>" method="POST"> -->
            <form action="<?php echo e(route('stugas.store')); ?>" method="post">
                <?php echo csrf_field(); ?>
                <div class="container">
                    <div class="row">
                        <div class="col-sm-2">
                            Surat Tugas *
                        </div>
                        <div class="col-sm-2">
                            <input type="text" name="no_st" placeholder="Surat Tugas"
                                class="form-control form-control-sm" value="<?php echo e(old('no_st')); ?> " required>
                        </div>
                        <div class="col-sm-auto">
                            Tanggal Surat Tugas *
                        </div>
                        <div class="col-sm-auto">
                            <input type="date" name="tgl_st" class="form-control form-control-sm"
                                value="<?php echo e(old('tgl_st')); ?> " required>
                        </div>
                        <div class="col-sm-auto">
                            Kota/Kabupaten *
                        </div>
                        <div class="col-sm-auto">
                            <input type="text" name="lokasi" placeholder="Kota / Kabupaten"
                                class="form-control form-control-sm" value="<?php echo e(old('lokasi')); ?>" required>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-sm-2"> <br>
                            Kode Anggaran *</br>
                        </div>
                        <div class="col-sm-10">
                            <br>
                            <select name="budget_id" class="form-control form-control-sm" required>
                                <option value="">- Pilih Anggaran</option>
                                <?php $__currentLoopData = $budgets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $budget): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($budget->id); ?>"
                                    <?php echo e(old('budget_id') == $budget->id ? 'selected' : null); ?>>
                                    <?php echo e($budget->sisa); ?> - <?php echo e($budget->uraian); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select> </br>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-sm-2">
                            Subdit Pengampu *
                        </div>
                        <div class="col-sm-4">
                            <select name="subdit_id" class="form-control form-control-sm" required>
                                <option value="">- Pilih Subdit</option>
                                <?php $__currentLoopData = $subdits; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subdit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($subdit->id); ?>"
                                    <?php echo e(old('subdit_id') == $subdit->id ? 'selected' : null); ?>>
                                    <?php echo e($subdit->subdit); ?> </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>

                        </div>
                        <div class="col-sm-auto">
                            Tanggal Pemeriksaan *
                        </div>
                        <div class="col-sm-auto">
                            <input type="date" name="tgl_audit" class="form-control form-control-sm"
                                value="<?php echo e(old('tgl_audit')); ?>">
                        </div>
                    </div>
                   <br>
                    <div class="row">
                        <div class="col-sm-2">
                            Auditor*
                        </div>
                        <div class="col-sm-4">
                            <select name="user_id[]" class="form-control form-control-sm" required>
                                <option value="">- Pilih Nama Pemeriksa 1</option>
                                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($user->id); ?>" <?php echo e(old('user_id[]') == $user->id ? 'selected' : null); ?>>
                                    <?php echo e($user->name); ?> </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="col-sm-4">
                            <select name="user_id[]" class="form-control form-control-sm" >
                                <option value="">- Pilih Nama Pemeriksa 2</option>
                                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($user->id); ?>" <?php echo e(old('user_id[]') == $user->id ? 'selected' : null); ?>>
                                    <?php echo e($user->name); ?> </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>
                    <br>
                    <div class="row">
                        <div class="col-sm-2">
                            Auditor Tambahan
                        </div>
                        <div class="col-sm-4">
                            <input type="text" name="tambahan" placeholder="Nama Pemeriksa Tambahan"
                                class="form-control form-control-sm" value="<?php echo e(old('tambahan')); ?>">
                        </div>
                    </div>
                    </br>
                    <div class="row">
                        <div class="col-sm-2">                             Biaya 
                        </div>
                        <div class="col-sm-4">
    
                            <input type="number" name="biaya" class="form-control form-control-sm"
                                value="<?php echo e(old('biaya')); ?>">
                        </div>
                    </div>
                    
                   
                    <div class="col-sm-8">
                        <button type="submit" class="btn btn-primary">Simpan</button>
                    </div>
            </form>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('lte.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/webhozz3/resources/views/stugas/create.blade.php ENDPATH**/ ?>