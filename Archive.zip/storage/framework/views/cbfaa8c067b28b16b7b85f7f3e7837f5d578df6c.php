<?php if($errors->any()): ?>
<div class="alert alert-outline alert-danger" role="alert">
     <h4 class="alert-heading">Oops!</h4>
     <p>Ada kesalahan. Mohon cek kembali form input. Terima kasih.</p>
     <hr>
     <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
     <p class="mb-0"><?php echo e($error); ?></p>
     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php endif; ?>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/webhozz3/resources/views/shared/errors.blade.php ENDPATH**/ ?>