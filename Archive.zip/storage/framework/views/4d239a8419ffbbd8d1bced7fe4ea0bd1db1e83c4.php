<?php $__env->startSection('content'); ?>
<section class="content-header">
    <div class="container-fluid">
        <div class="row mb-0">
            <div class="col-sm-6">
                <h1>Ubah Data Audit</h1>
            </div>
            <div class="col-sm-6">
                <ol class="breadcrumb float-sm-right">
                    <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>">Dashboard</a></li>
                    <li class="breadcrumb-item"><a href="<?php echo e(route('iku.index')); ?>">Kinerja</a></li>
                    <li class="breadcrumb-item active">Ubah</li>
                </ol>
            </div>
        </div>
    </div><!-- /.container-fluid -->
</section>
<section class="content">
<div class="card">
    <div class="card-header">
<form action="<?php echo e(route('iku.update', $iku->id)); ?>" method="POST">
     <?php echo csrf_field(); ?>
     <?php echo e(method_field("PATCH")); ?>

     <!-- <div class="col-md-6">
          <label>Kode Indikator Kinerja</label>
          <input type="text" name="kode" placeholder="eg: 121837182" class="form-control" value="<?php echo e($iku->kode); ?>" required>
     </div> -->
     <div class="col-md-6">
          <label>Sasaran Kegiatan</label>
          <input type="text" name="sasaran" class="form-control" value="<?php echo e($iku->sasaran); ?>" required>
     </div>
     <div class="col-md-6">
          <label>Indikator Kinerja</label>
          <input type="text" name="indikator" class="form-control" value="<?php echo e($iku->indikator); ?>">         
     </div>
     <div class="col-md-6">
          <label>Target</label>
          <input type="text" name="target" class="form-control" value="<?php echo e($iku->target); ?>"required>
     </div>
     <div class="col-md-6">
          <label>Realisasi</label>
          <input type="number" name="realisasi" class="form-control" value="<?php echo e($iku->realisasi); ?>" disabled>
     </div>
     <div class="col-md-6 mt-3">
          <button type="submit" class="btn btn-primary">Simpan</button>
     </div>
</form>
</div>
</div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('lte.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/webhozz3/resources/views/iku/edit.blade.php ENDPATH**/ ?>