<?php $__env->startSection('content'); ?>
<?php echo $__env->make('shared.errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- Content Header (Page header) -->
<section class="content-header">
    <div class="container-fluid">
        <div class="row mb-0">
            <div class="col-sm-6">
                <h1>Tambah Audit</h1>
                * harus diisi
            </div>
            <div class="col-sm-6">
                <ol class="breadcrumb float-sm-right">
                    <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>">Dashboard</a></li>
                    <li class="breadcrumb-item"><a href="<?php echo e(route('audit.index')); ?>">Audit</a></li>
                    <li class="breadcrumb-item active">Tambah</li>
                </ol>
            </div>
        </div>
    </div><!-- /.container-fluid -->
</section>
<section class="content"> 
    <div class="card">
        <div class="card-header">
            <form action="<?php echo e(asset("/audit")); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <div class="container">
                    <div class="row">
                        <div class="col-sm-2">
                            Surat Tugas *
                        </div>
                        <div class="col-sm-4">
                                <select name="stugas_id" class="form-control form-control-sm" required>
                                <option value="">- Pilih Surat Tugas</option>
                                <?php $__currentLoopData = $stugas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $stugas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($stugas->id); ?>"
                                    <?php echo e(old('stugas_id') == $stugas->id ? 'selected' : null); ?>>
                                    <?php echo e($stugas->no_st); ?> | <?php echo e(date('d-M-y', strtotime($stugas->tgl_st))); ?> | <?php echo e($stugas->lokasi); ?>  </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select> 

                        </div>
                        <div class="col-sm-2"> 
                            Jenis Sarana *
                        </div>
                        <div class="col-sm-3">
                            <select name="jenis_sarana" class="form-control form-control-sm" required>
                                <option value="">- Pilih Jenis Sarana</option>
                                <option value="Produksi">Sarana Produksi IRTP</option>
                                <option value="Produksi">Sarana Produksi MD</option>
                                <option value="Produksi">Sarana Produksi ML</option>
                                <option value="Distribusi">Sarana Distribusi Importir</option>
                                <option value="Distribusi">Sarana Distribusi Retail</option>
                                <option value="Distribusi">Gudang Distribusi</option>
                                <option value="Produksi & Distribusi">Produksi & Distribusi</option>
                            </select>
                          
                        </div>
                    </div>
                    
                   
                    <div class="row">
                        <div class="col-sm-2"> <br>
                            Nama Sarana *</br>
                        </div>
                        <div class="col-sm-4">
                            <br>
                            <select name="sarana_id" class="form-control form-control-sm" required>
                                <option value="">- Pilih Sarana</option>
                                <?php $__currentLoopData = $saranas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sarana): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($sarana->id); ?>"
                                    <?php echo e(old('sarana_id') == $sarana->id ? 'selected' : null); ?>>
                                    <?php echo e($sarana->nama); ?> </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select></br>
                        </div>
                        <div class="col-sm-auto"><br>
                            Tanggal Pemeriksaan*
                        </div></br>
                        <div class="col-sm-3"><br>
                            <input type="date" name="tgl_audit" class="form-control form-control-sm"
                                value="<?php echo e(old('tgl_audit')); ?>">
                        </div></br>
                    </div>
                    <div class="row">
                        <div class="col-sm-2">
                            Alamat Sarana
                        </div>
                        <div class="col-sm-4">
                            <textarea name="alamat" class="form-control" required> <?php echo e(old('alamat')); ?></textarea>
                        </div>
                    </div>
                    <div class="card-header">
                    </div>
                    <div class="row">
                        <div class="col-sm-2"> <br>
                            Jenis Kegiatan *</br>
                        </div>
                        <div class="col-sm-4">
                            <br>
                            <input type="hidden" name="jenis_keg[]" value=" ">
                            <input type="checkbox" name="jenis_keg[]" value="Pemeriksaan Sarana (Verifikasi/Rutin)">
                            Pemeriksaan Sarana (Verifikasi/Rutin)
                            <br>
                            <input type="checkbox" name="jenis_keg[]" value="Pengamanan">
                            Pengamanan
                            <br>
                            <input type="checkbox" name="jenis_keg[]" value="Pemusnahan">
                            Pemusnahan
                            <br>
                            <input type="checkbox" name="jenis_keg[]" value="Pengambilan Sampel">
                            Pengambilan Sampel
                            <br>
                            <input type="checkbox" name="jenis_keg[]" value="Penelusuran Kasus">
                            Penelusuran Kasus
                            <br>
                            <input type="checkbox" name="jenis_keg[]" value="Sertifikasi CPPOB">
                            Sertifikasi CPPOB
                            <br>
                            <input type="checkbox" name="jenis_keg[]" value="Pemeriksaan Sarana Baru (PSB)">
                            Pemeriksaan Sarana Baru (PSB)
                            <br>
                            <input type="checkbox" name="jenis_keg[]" value="Pembukaan Segel">
                            Pembukaan Segel
                        </div>
                        <div class="col-sm-4">
                            <br>
                            <input type="checkbox" name="jenis_keg[]" value="Sertifikasi HS">
                            Sertifikasi HS
                            <br>
                            <input type="checkbox" name="jenis_keg[]" value="Izin Produsen BTP">
                            Izin Produsen BTP
                            <br>
                            <input type="checkbox" name="jenis_keg[]" value="Audit dalam Rangka Ekspor">
                            Audit dalam Rangka Ekspor
                            <br>
                            <input type="checkbox" name="jenis_keg[]" value="Surveillan Sertifikasi CPPOB">
                            Surveillan Sertifikasi CPPOB
                            <br>
                            <!-- <input type="checkbox" name="jenis_keg[]" value="<?php echo e(old('jenis_keg[]')); ?>" >
               Lainnya:<input type="text" name="jenis_keg[]" class="form-control form-control-sm"> -->
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-sm-2"><br>
                            Hasil Pemeriksaan / Temuan
                        </div>
                        <div class="col-sm-8"><br>
                            <textarea name="hasil" class="form-control" required> <?php echo e(old('hasil')); ?></textarea></br>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-sm-2">
                            Kesimpulan
                        </div>
                        <div class="col-sm-2">
                            <input type="hidden" name="kesimpulan[]" value=" ">
                            <input type="checkbox" id="kesimpulan" name="kesimpulan[]" value="TMK Label">
                            TMK Label
                            <br>
                            <input type="checkbox" id="kesimpulan" name="kesimpulan[]" value="Tanpa Izin Edar">
                            Tanpa Izin Edar
                            <br>
                            <input type="checkbox" id="kesimpulan" name="kesimpulan[]" value="TMS Produk">
                            TMS Produk
                        </div>
                        <div class="col-sm-2">
                            <input type="checkbox" id="kesimpulan" name="kesimpulan[]" value="Tidak Memiliki SKI">
                            Tidak Memiliki SKI
                            <br>
                            <input type="checkbox" id="kesimpulan" name="kesimpulan[]" value="Mayor">
                            Mayor
                            <br>
                            <input type="checkbox" id="kesimpulan" name="kesimpulan[]" value="Minor">
                            Minor
                            <br>
                            </div>
                        <div class="col-sm-2">
                            <input type="checkbox" id="kesimpulan" name="kesimpulan[]" value="Kritis Serius">
                            Kritis Serius
                            <br>
                            <input type="checkbox" id="kesimpulan" name="kesimpulan[]" value="Tidak Ada Temuan">
                            Tidak Ada Temuan
                            <br>
                            <!-- <input type="checkbox" id="kesimpulan" name="kesimpulan[]" value="<?php echo e(old('isikesimpulan')); ?>" >
          Lainnya:<input type="text" name="isikesimpulan" class="form-control form-control-sm"> -->
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-sm-2"> <br>
                            Rating Sarana Produksi
                        </div>
                       
                        <div class="col-sm-2"><br>
                        <input type="hidden" name="rating_produksi[]" value=" ">
                            <input type="checkbox" name="rating_produksi[]" value="A"> A
                            <input type="checkbox" name="rating_produksi[]" value="B"> B
                            <input type="checkbox" name="rating_produksi[]" value="C"> C
                            <input type="checkbox" name="rating_produksi[]" value="D"> D
                            </div>
                            <div class="col-sm-4 checkbox"><br>
                            <input type="checkbox" name="rating_produksi[]" value="Level I"> Level I
                            <input type="checkbox" name="rating_produksi[]" value="Level II"> Level II
                            <input type="checkbox" name="rating_produksi[]" value="Level III"> Level III
                            <input type="checkbox" name="rating_produksi[]" value="Level IV"> Level IV
                        </div>
                        <div class="col-sm-2 checkbox"><br>
                        <input type="checkbox" name="rating_produksi[]" value="TDP"> TDP
                        <input type="checkbox" name="rating_produksi[]" value="TTP"> TTP
                        </div>
                        </br>
                    </div>
                    <div class="row">
                        <div class="col-sm-2"> <br>
                            Rating Sarana Distribusi
                        </div>
                        <div class="col-sm-8 radio"><br>
                        <input type="hidden" name="rating_distribusi[]" value=" ">
                            <input type="checkbox" name="rating_distribusi[]" value="Baik"> Baik
                            <input type="checkbox" name="rating_distribusi[]" value="Cukup"> Cukup
                            <input type="checkbox" name="rating_distribusi[]" value="Kurang"> Kurang
                            <input type="checkbox" name="rating_distribusi[]" value="TDP"> TDP
                            <input type="checkbox" name="rating_distribusi[]" value="TTP"> TTP
                        </div>
                        </br>
                    </div>
                    
                    <input type="hidden" name="status_capa" 
                        class="form-control form-control-sm" value="Ditugaskan melakukan audit" required>
                   
                    <div class="col-sm-8">
                        <button type="submit" class="btn btn-primary">Simpan</button>
                    </div>
            </form>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('lte.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/webhozz3/resources/views/audit/create.blade.php ENDPATH**/ ?>