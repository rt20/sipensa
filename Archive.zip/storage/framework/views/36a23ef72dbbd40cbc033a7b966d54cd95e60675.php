<?php $__env->startSection('content'); ?>
<!-- Content Header (Page header) -->
<section class="content-header">
    <div class="container-fluid">
        <div class="row mb-0">
            <div class="col-sm-9">
                <h1>Surat Tugas</h1>
            </div>
            <div class="col-sm-3">
                <ol class="breadcrumb float-sm-right">
                    <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>">Dashboard</a></li>
                    <li class="breadcrumb-item active">Surat Tugas</li>
                </ol>
            </div>  
        </div>
    </div><!-- /.container-fluid -->
</section>
<section class="content">
<div class="card">
    <div class="card-header">
    <a href="<?php echo e(route('stugas.create')); ?>" class="btn btn-primary" title="Tambah Surat Tugas"><i class="nav-icon fas fa-plus-circle"></i> </a>
       
        </div>
        <div class="card-body">
        <table class="table">
            <thead class="thead-light">
                <tr>
                    <th scope="col">No</th>
                    <th scope="col">Surat Tugas</th>
                    <th scope="col">Tanggal</th>
                    <th scope="col">Lokasi</th>
                    <th scope="col">Biaya</th>
                    
                    <th scope="col" colspan="2">Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <th><?php echo e(($data->currentPage()-1) * $data->perPage()+$loop->index+1); ?></th>
                    <td><?php echo e($row->no_st); ?></td>
                    <td><?php echo e(date('d-M-y', strtotime($row->tgl_st))); ?></td>
                    <td><?php echo e($row->lokasi); ?></td>
                    <td> Rp<?php echo e(number_format($row->biaya)); ?></td>
                    <td>
                    <a href="<?php echo e(route('stugas.edit', $row->id)); ?>" class="btn btn-success btn-sm" title="Ubah">
                            <i class="fa fa-edit"></i></a>
                            <form action="<?php echo e(route('stugas.destroy', $row->id)); ?>" method="post" class="d-inline" title="Hapus">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('delete'); ?>
                            <button class="btn btn-danger btn-sm " onclick="return confirm('Apakah anda yakin ?')">
                                <i class="fa fa-trash"></i>
                            </button>
                        </form>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="8">Data tidak ditemukan</td>
                </tr>
                <?php endif; ?>

            </tbody>
        </table>

    </div>

</div>

<?php echo $data->render(); ?>

</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('lte.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/webhozz3/resources/views/stugas/index.blade.php ENDPATH**/ ?>